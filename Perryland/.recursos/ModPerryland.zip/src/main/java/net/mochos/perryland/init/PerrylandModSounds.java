
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mochos.perryland.init;

import net.mochos.perryland.PerrylandMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

public class PerrylandModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, PerrylandMod.MODID);
	public static final RegistryObject<SoundEvent> YOURBLOOD = REGISTRY.register("yourblood", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("perryland", "yourblood")));
}
