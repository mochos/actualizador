
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mochos.perryland.init;

import net.mochos.perryland.block.CajamonedasBlock;
import net.mochos.perryland.PerrylandMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

public class PerrylandModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, PerrylandMod.MODID);
	public static final RegistryObject<Block> CAJAMONEDAS = REGISTRY.register("cajamonedas", () -> new CajamonedasBlock());
}
