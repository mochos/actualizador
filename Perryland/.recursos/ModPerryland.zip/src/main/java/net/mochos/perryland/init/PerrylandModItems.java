
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mochos.perryland.init;

import net.mochos.perryland.item.YourBloodItem;
import net.mochos.perryland.item.PilamonedasItem;
import net.mochos.perryland.item.MonedaItem;
import net.mochos.perryland.item.ClusterItem;
import net.mochos.perryland.item.BolsamonedasItem;
import net.mochos.perryland.item.AlmaItem;
import net.mochos.perryland.PerrylandMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

public class PerrylandModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, PerrylandMod.MODID);
	public static final RegistryObject<Item> PILAMONEDAS = REGISTRY.register("pilamonedas", () -> new PilamonedasItem());
	public static final RegistryObject<Item> MONEDA = REGISTRY.register("moneda", () -> new MonedaItem());
	public static final RegistryObject<Item> BOLSAMONEDAS = REGISTRY.register("bolsamonedas", () -> new BolsamonedasItem());
	public static final RegistryObject<Item> CAJAMONEDAS = block(PerrylandModBlocks.CAJAMONEDAS);
	public static final RegistryObject<Item> ALMA = REGISTRY.register("alma", () -> new AlmaItem());
	public static final RegistryObject<Item> CLUSTER = REGISTRY.register("cluster", () -> new ClusterItem());
	public static final RegistryObject<Item> YOUR_BLOOD = REGISTRY.register("your_blood", () -> new YourBloodItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
