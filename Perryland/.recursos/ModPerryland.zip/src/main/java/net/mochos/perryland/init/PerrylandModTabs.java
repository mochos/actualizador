
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mochos.perryland.init;

import net.mochos.perryland.PerrylandMod;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

public class PerrylandModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, PerrylandMod.MODID);
	public static final RegistryObject<CreativeModeTab> PERRYLAND = REGISTRY.register("perryland",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.perryland.perryland")).icon(() -> new ItemStack(PerrylandModItems.BOLSAMONEDAS.get())).displayItems((parameters, tabData) -> {
				tabData.accept(PerrylandModItems.PILAMONEDAS.get());
				tabData.accept(PerrylandModItems.MONEDA.get());
				tabData.accept(PerrylandModItems.BOLSAMONEDAS.get());
				tabData.accept(PerrylandModBlocks.CAJAMONEDAS.get().asItem());
				tabData.accept(PerrylandModItems.YOUR_BLOOD.get());
			}).withSearchBar().build());
}
